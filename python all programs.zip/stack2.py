stack=["Sahil","ram","Samar","Prashant"]
print("stack:",stack)
stack.append("PAlak")
stack.append("Sandeepa")
print("New_stack",stack)
print("Deleted item:",stack.pop())
print(stack)
print("Deleted item:",stack.pop())
print(stack)




