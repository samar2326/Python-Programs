""" Program 8: WAP to demonstrate use of tuple & related functions"""
tup1=('Samar','Sahil','2326','2305')
tup2=("r","p","q","s")
tup3=(1,2,4,6,8,7,8)
print("tup1[0:3]:",tup1[0:3])
print("tup2[1:4]:",tup2[1:4])
print("tup3[3:5]",tup3[3:5])
