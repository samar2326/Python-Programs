""" Program 1: WAP to demonstrate the working 'id' and 'type' function."""
x=2326
y=2326
z=2610.1998	
str1="Samar"
str2="SAhil"
tup = (23,26,5,10,98);
list = [12,'d',65,'f',123]
print ( id(x), id(y)  ,id(z) , id(str1) , id(str2) , id(tup) , id(list))
print ( type(x) , type(y) , type(z) , type(str1) , type(str2) , type(tup) , type(list))