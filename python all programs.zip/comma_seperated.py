""" Program 6.b :Write a program that accepts a comma separated sequence of words as input and prints the words in a comma-separated sequence after sorting them alphabetically.
"""
values = input("enter comma seperated words :")
l = values.split(",")
t = tuple(l)
print (l)
print (t)
