""" Program 3: WAP to demonstratenb using of slicing in string. """
str = "Samar"
sliceObj = slice(3)
print(str[sliceObj])
sliceObj = slice(1, 4)
print(str[sliceObj])
sliceObj = slice(0, 2)

print(str[sliceObj])
sliceObj = slice(1, 3)

print(str[sliceObj])
sliceObj = slice(0, 4)

print(str[sliceObj])
sliceObj = slice(1, 3)